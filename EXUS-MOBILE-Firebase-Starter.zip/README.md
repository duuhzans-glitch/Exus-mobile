# EXUS-MOBILE — Firebase Key Manager

## O que está incluído
- Painel web com o visual EXUS.
- Login por Firebase Authentication.
- Geração de Keys permanente, 24h, 7 dias e 30 dias.
- Revogação e listagem via Cloud Functions.
- Validação pública por HTTPS para o cliente Delta.
- Keys guardadas como SHA-256; o texto original é mostrado somente uma vez.
- Regras do Realtime Database fechadas para acesso direto do cliente.

## 1. Preparar Firebase
No console do projeto `exus-mobile`:
1. Authentication → Sign-in method → habilite **E-mail/senha**.
2. Authentication → Users → **Add user**. Crie seu usuário administrativo.
3. Realtime Database → Rules: serão publicadas regras que negam leitura/escrita direta.
4. Confirme que o plano Blaze está ativo: Cloud Functions e Hosting podem exigir faturamento.

## 2. Dar permissão de administrador
A claim `admin` deve ser aplicada pelo Firebase Admin SDK, nunca pelo navegador.
1. Em Configurações do projeto → Contas de serviço, gere uma chave privada para uma conta de serviço.
2. Guarde o JSON fora da pasta `public` e nunca envie para ninguém.
3. No terminal, dentro de `functions`, instale dependências: `npm install`.
4. Com Node.js instalado, execute:
   `GOOGLE_APPLICATION_CREDENTIALS="/caminho/service-account.json" node set-admin.js SEU_EMAIL`
5. Apague a chave de serviço local quando terminar e mantenha-a fora do site.

## 3. Publicar
Instale Node.js e Firebase CLI. No diretório do projeto:
- `npm install -g firebase-tools`
- `firebase login`
- `firebase use exus-mobile`
- `cd functions && npm install && cd ..`
- `firebase deploy --only database,functions,hosting`

O endereço do painel será `https://exus-mobile.web.app`.

## 4. Endpoint para o script
POST `https://southamerica-east1-exus-mobile.cloudfunctions.net/validateKey`
JSON: `{"key":"EXUS-XXXX-XXXX-XXXX-XXXX"}`
Resposta válida: `{"valid":true,"expiresAt":null}`.
Key inválida, expirada ou revogada: `{"valid":false}`.

O cliente deve liberar somente a funcionalidade licenciada quando `valid == true`.
Não coloque a service-account, Admin SDK ou segredos administrativos no HTML/script cliente.

## Notas
- A configuração `firebaseConfig` do app Web é pública por projeto; a proteção vem das regras, Authentication, claims e Cloud Functions.
- O painel só permite login a contas com custom claim `admin: true`.
- A função de validação é pública por desenho, portanto implemente limites de uso/monitoramento no projeto antes de distribuir em larga escala.
- O projeto usa `southamerica-east1` para as funções.
