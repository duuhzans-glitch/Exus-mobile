// Execute localmente após baixar uma chave de conta de serviço.
// Uso: GOOGLE_APPLICATION_CREDENTIALS="./service-account.json" node set-admin.js EMAIL
const admin=require("firebase-admin");
admin.initializeApp({credential:admin.credential.applicationDefault()});
(async()=>{
 const email=process.argv[2];if(!email)throw new Error("Informe o e-mail: node set-admin.js admin@exemplo.com");
 const user=await admin.auth().getUserByEmail(email);
 await admin.auth().setCustomUserClaims(user.uid,{admin:true});
 console.log("Permissão admin aplicada para",email,"UID:",user.uid);
 process.exit(0);
})().catch(e=>{console.error(e);process.exit(1)});
