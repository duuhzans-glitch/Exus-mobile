const {onCall,onRequest,HttpsError}=require("firebase-functions/v2/https");
const {initializeApp}=require("firebase-admin/app");
const {getDatabase}=require("firebase-admin/database");
const crypto=require("crypto");
initializeApp();
const db=getDatabase();
const durations={daily:24*60*60*1000,weekly:7*24*60*60*1000,monthly:30*24*60*60*1000};
function requireAdmin(req){if(!req.auth||req.auth.token.admin!==true)throw new HttpsError("permission-denied","Acesso administrativo necessário.");}
function hashKey(key){return crypto.createHash("sha256").update(String(key).trim()).digest("hex");}
function newKey(){const alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";const bytes=crypto.randomBytes(16);let s="EXUS-";for(let i=0;i<16;i++){if(i&&i%4===0)s+="-";s+=alphabet[bytes[i]%alphabet.length]}return s;}
exports.generateKey=onCall({region:"southamerica-east1"},async(req)=>{
  requireAdmin(req);const type=req.data?.type;
  if(!["permanent","daily","weekly","monthly"].includes(type))throw new HttpsError("invalid-argument","Tipo de Key inválido.");
  const key=newKey(),id=db.ref("keys").push().key,createdAt=Date.now();
  const expiresAt=type==="permanent"?null:createdAt+durations[type],hash=hashKey(key);
  const updates={};updates[`keys/${id}`]={type,createdAt,expiresAt,revoked:false};updates[`keyHashes/${hash}`]={id};
  await db.ref().update(updates);
  return {key,id,createdAt,expiresAt,type};
});
exports.listKeys=onCall({region:"southamerica-east1"},async(req)=>{
  requireAdmin(req);const snap=await db.ref("keys").get(),obj=snap.val()||{};
  const keys=Object.entries(obj).map(([id,k])=>({id,...k})).sort((a,b)=>b.createdAt-a.createdAt);
  return {keys};
});
exports.revokeKey=onCall({region:"southamerica-east1"},async(req)=>{
  requireAdmin(req);const id=String(req.data?.id||"");
  if(!/^[A-Za-z0-9_-]{8,}$/.test(id))throw new HttpsError("invalid-argument","ID inválido.");
  const ref=db.ref(`keys/${id}`),snap=await ref.get();if(!snap.exists())throw new HttpsError("not-found","Key não encontrada.");
  await ref.update({revoked:true,revokedAt:Date.now()});return {ok:true};
});
exports.validateKey=onRequest({region:"southamerica-east1",cors:true},async(req,res)=>{
  if(req.method!=="POST")return res.status(405).json({valid:false,error:"method_not_allowed"});
  const key=String(req.body?.key||"").trim();
  if(!/^EXUS-[A-Z2-9]{4}(?:-[A-Z2-9]{4}){3}$/.test(key))return res.status(200).json({valid:false});
  try{
    const index=await db.ref(`keyHashes/${hashKey(key)}`).get();if(!index.exists())return res.status(200).json({valid:false});
    const snap=await db.ref(`keys/${index.val().id}`).get();if(!snap.exists())return res.status(200).json({valid:false});
    const k=snap.val(),expired=!!k.expiresAt&&Date.now()>k.expiresAt;
    return res.status(200).json({valid:!k.revoked&&!expired,expiresAt:k.expiresAt||null});
  }catch(e){return res.status(500).json({valid:false,error:"validation_unavailable"});}
});
